# this key will not be functional after the IRE conference
# Replace it with your own by signing up at this site
# http://api.census.gov/data/key_signup.html

census_key <- "33db52b83cf8c0da82b49dd713c0018f3e9912a8"